var progress = 0;
var loadlock = false;
function loader(time) {
  if (loadlock === false) {
    loadlock = true;
    cover.style.zIndex = "10";
    cover.style.opacity = "1";
    if (time != undefined) {
      var load = setTimeout(function () {
        progress = 0;
        loadlock = false
        cover.style.zIndex = "-1";
        cover.style.opacity = "0";
      }, time)
    } else {
      setInterval(function () {
        if (progress >= 100) {
          clearInterval(load);
          progress = 0;
          loadlock = false;
          cover.style.zIndex = "-1";
          cover.style.opacity = "0";
        }
      }, 50)
    }
  }
};