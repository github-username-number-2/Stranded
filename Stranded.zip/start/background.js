var bcgrnd = createmenuitem("bcgrnd", "background", "img", "", 1366, 786, 0, 0, 0, 0, "posa");
bcgrnd.style.zIndex = "-4";
bcgrnd.style.opacity = "0.85";
var bcgrnd2 = createmenuitem("bcgrnd2", "background", "img", "", 1366, 786, 0, 0, 1, 0, "posa");
bcgrnd2.style.zIndex = "-4";
bcgrnd2.style.opacity = "0.85";
rotateb();
rotateb();
function rotateb() {
  bcgrnd.style.left = "0px";
  bcgrnd2.style.left = "1365.9px";
  $(bcgrnd).animate({ left: -1366 }, {
    duration: 20000,
    easing: "linear",
    queue: false
  });
  $(bcgrnd2).animate({ left: 0 }, {
    duration: 20000,
    easing: "linear",
    queue: false,
    complete: function () { rotateb() }
  })
};