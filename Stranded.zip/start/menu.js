$("body").css({ "cursor": "url(/imgs/eimgs/cursor.png), default" });
c = true;
$("body").mousedown(function () {
  if (c === true) {
    $("body").css({ "cursor": "url(/imgs/eimgs/cursorsmall.png), default" })
  }
});
$("body").mouseup(function () {
  if (c === true) {
    $("body").css({ "cursor": "url(/imgs/eimgs/cursor.png), default" })
  }
});
body.onmouseup = function () {
  if (document.getElementById("play") != null) {
    play.style.filter = "brightness(100%)";
    entersettings.style.filter = "brightness(100%)";
    info.style.filter = "brightness(100%)";
    back1.style.filter = "brightness(100%)";
    back2.style.filter = "brightness(100%)";
    back3.style.filter = "brightness(100%)";
    back4.style.filter = "brightness(100%)";
    ss1.style.filter = "brightness(100%)";
    ss2.style.filter = "brightness(100%)";
    ss3.style.filter = "brightness(100%)";
    ss4.style.filter = "brightness(100%)";
    settingsb1.style.filter = "brightness(100%)";
    settingsb2.style.filter = "brightness(100%)";
    settingsb3.style.filter = "brightness(100%)";
    settingsb4.style.filter = "brightness(100%)";
    start.style.filter = "brightness(100%)";
    deleteb.style.filter = "brightness(100%)";
  }
};
let bg = document.createElement("script");
bg.setAttribute("src", "/start/background.js");
body.appendChild(bg);



//buttons
//buttons

//name, filename, type, value, width, height, left, top, pagex, pagey, clas, onclick, lsize, lsizeposx, lsizeposy, size, shiftdirection, action

//page1
createmenuitem("play", "playb", "img", "", 400, false, 483, 300, 0, 0, "menuitem", true, 425, 470.5, false, false, "right");
createmenuitem("entersettings", "settingsb", "img", "", 225, false, 570.5, 460, 0, 0, "menuitem", true, 250, 558, false, false, "left");
createmenuitem("info", "infob", "img", "", 150, false, 608, 550, 0, 0, "menuitem", true, 175, 595.5, false, false, "down");
//page1
//ss
createmenuitem("savesloth", "", "h1", "Select save slot.", false, false, 490, 100, 1, 0, "menuitem", false, false, false, false, "20px");
createmenuitem("ss1", "ss", "img", "", 250, false, 75, 225, 1, 0, "menuitem", true, 275, 62.5, false, false, "right", "saveslot='ss1';updateskin()");
createmenuitem("ss2", "ss", "img", "", 250, false, 400, 225, 1, 0, "menuitem", true, 275, 387.5, false, false, "right", "saveslot='ss2';updateskin()");
createmenuitem("ss3", "ss", "img", "", 250, false, 716, 225, 1, 0, "menuitem", true, 275, 703.5, false, false, "right", "saveslot='ss3';updateskin()");
createmenuitem("ss4", "ss", "img", "", 250, false, 1041, 225, 1, 0, "menuitem", true, 275, 1028.5, false, false, "right", "saveslot='ss4';updateskin()");
createmenuitem("ss1h", "", "h1", datess1, false, false, 85, 175, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss2h", "", "h1", datess2, false, false, 410, 175, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss3h", "", "h1", datess3, false, false, 726, 175, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss4h", "", "h1", datess4, false, false, 1051, 175, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("gss1h", "", "h1", "x" + goldss1, false, false, 135, 275, 1, 0, "menuitem", false, false, false, false, "20px");
createmenuitem("gss2h", "", "h1", "x" + goldss2, false, false, 460, 275, 1, 0, "menuitem", false, false, false, false, "20px");
createmenuitem("gss3h", "", "h1", "x" + goldss3, false, false, 776, 275, 1, 0, "menuitem", false, false, false, false, "20px");
createmenuitem("gss4h", "", "h1", "x" + goldss4, false, false, 1101, 275, 1, 0, "menuitem", false, false, false, false, "20px");
createmenuitem("ss1nm", "", "h1", ss1n, false, false, 105, 475, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss2nm", "", "h1", ss2n, false, false, 430, 475, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss3nm", "", "h1", ss3n, false, false, 746, 475, 1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("ss4nm", "", "h1", ss4n, false, false, 1071, 475, 1, 0, "menuitem", false, false, false, false, "18px");
//ss
//back
createmenuitem("back1", "backb", "img", "", 125, false, 1170, 675, -1, 0, "menuitem", true, 150, 1157.5, false, false, "right");
createmenuitem("back2", "backb", "img", "", 125, false, 75, 675, 1, 0, "menuitem", true, 150, 62.5, false, false, "left");
createmenuitem("back3", "backb", "img", "", 125, false, 75, 675, 2, 0, "menuitem", true, 150, 62.5, false, false, "left", "saveslot=''");
createmenuitem("back4", "backb", "img", "", 125, false, 75, 675, 0, 1, "menuitem", true, 150, 62.5, false, false, "up");
//back
//ssinfo
var back = createmenuitem("ssinfo", "saveinfo", "img", "", 1300, false, 33, 75, 2, 0, "menuitem");
back.style.zIndex = "-1";
createmenuitem("start", "startb", "img", "", 215, false, 1015, 566.5, 2, 0, "menuitem", true, 215, 1015, false, false, false, "startgame()");
var pskin = createmenuitem("plyrskin", "", "img", "", 200, false, 1020, 230, 2, 0, "menuitem", false, false, false, false, false, false, false, false);
function updateskin() {
  pskin.setAttribute("src", "/imgs/skins/" + eval(("playerskin" + saveslot)) + "/down.png")
};
//ssinfo
//settings
var settings = createmenuitem("settingsback", "settingsback", "img", "", false, 600, 423, 125, -1, 0, "menuitem");
settings.style.zIndex = "-1";
var sb1x;
if (autosave === "true") { sb1x = 823 } else { sb1x = 783 };
var settingsb1 = createmenuitem("settingsb1", "settingsbutton", "img", "", 40, 80, sb1x, 225, -1, 0, "menuitem", true, false, false, 225, false, false, "if(autosave==='true'){autosave='false';setsave('autosave','false');settingsb1.style.left='823px';$(settingsb1).animate({left:'-=40'},300)}else{autosave='true';setsave('autosave','true');settingsb1.style.left='823px'}");
var sb2x;
if (showcoords === "true") { sb2x = 823 } else { sb2x = 783 };
var settingsb2 = createmenuitem("settingsb2", "settingsbutton", "img", "", 40, 80, sb2x, 325, -1, 0, "menuitem", true, false, false, 225, false, false, "if(showcoords==='true'){showcoords='false';setsave('showcoords','false');settingsb2.style.left='823px';$(settingsb2).animate({left:'-=40'},300)}else{showcoords='true';setsave('showcoords','true');settingsb2.style.left='823px'}");
var sb3x;
if (showwcoords === "true") { sb3x = 823 } else { sb3x = 783 };
var settingsb3 = createmenuitem("settingsb3", "settingsbutton", "img", "", 40, 80, sb3x, 425, -1, 0, "menuitem", true, false, false, 225, false, false, "if(showwcoords==='true'){showwcoords='false';setsave('showwcoords','false');settingsb3.style.left='823px';$(settingsb3).animate({left:'-=40'},300)}else{showwcoords='true';setsave('showwcoords','true');settingsb3.style.left='823px'}");
var sb4x;
if (showmap === "true") { sb4x = 823 } else { sb4x = 783 };
var settingsb4 = createmenuitem("settingsb4", "settingsbutton", "img", "", 40, 80, sb4x, 525, -1, 0, "menuitem", true, false, false, 225, false, false, "if(showmap==='true'){showmap='false';setsave('showmap','false');settingsb4.style.left='823px';$(settingsb4).animate({left:'-=40'},300)}else{showmap='true';setsave('showmap','true');settingsb4.style.left='823px'}");
createmenuitem("settings1h", "", "h1", "Autosave", false, false, 475, 240, -1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("settings2h", "", "h1", "Player<br>Coordinates", false, false, 475, 340, -1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("settings3h", "", "h1", "World<br>Coordinates", false, false, 475, 440, -1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("settings4h", "", "h1", "World Map", false, false, 475, 540, -1, 0, "menuitem", false, false, false, false, "18px");
createmenuitem("deleteb", "deleteb", "img", "", 150, false, 608, 600, -1, 0, "menuitem", true, 150, 608, false, false, false, "if(confirm('Delete all save data? All progress will be lost.')===true){if(confirm('Are you sure?')===true){if(confirm('Are you very very sure?')===true){if(confirm('This can not be undone.')===true){if(confirm('Last chance.')===true){window.localStorage.clear();location.reload()}}}}}");

//settings

//info
var infotext = document.createElement("div");

//info

//name, filename, type, value, width, height, left, top, pagex, pagey, clas, onclick, lsize, lsizeposx, lsizeposy, size, shiftdirection, action


//
//

var versionh = document.createElement("p");
versionh.innerHTML = version;
versionh.setAttribute("class", "bc2");
versionh.style.bottom = "-20px";
versionh.style.right = "0px";
versionh.style.zIndex = "1";
versionh.style.fontSize = "20px";
body.appendChild(versionh);

function startgame() {
  cover.style.zIndex = "10";
  cover.style.opacity = "1";
  setTimeout(function () {
    cover.style.zIndex = "-1";
    cover.style.opacity = "0";
    progress = 100;
  }, 5000);
  var s1 = document.createElement("script");
  s1.setAttribute("src", "/world/createworld.js");
  var s2 = document.createElement("script");
  s2.setAttribute("src", "/playerscripts/createplayer.js");
  body.appendChild(s1);
  body.appendChild(s2);
  var menuitem = document.getElementsByClassName("menuitem");
  while (menuitem[0] != null) {
    body.removeChild(menuitem[0])
  };
  body.removeChild(versionh);
  body.removeChild(bcgrnd);
  body.removeChild(bcgrnd2);
};
