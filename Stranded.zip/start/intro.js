//$("body").css({ "cursor": "url(/eimgs/blank.png), default" });
var cover = document.createElement("img");
cover.setAttribute("src", "/imgs/bbackground.png");
cover.setAttribute("class", "posa");
cover.setAttribute("draggable", "false");
cover.style.zIndex = "4";
cover.style.top = "0px";
cover.style.left = "0px";
cover.style.width = "1386px"
cover.style.height = "1768px";
body.appendChild(cover);
/*var heading = document.createElement("h3");
heading.setAttribute("class", "bc2");
heading.setAttribute("id", "heading");
heading.innerHTML = "Made with:";
heading.style.zIndex = "4";
heading.style.color = "#8a8a8a";
heading.style.textAlign = "right";
body.appendChild(heading);
heading.style.left = "639px";
heading.style.top = "275px";
var htmllogo = document.createElement("img");
htmllogo.setAttribute("src", "/imgs/htmllogo.png");
htmllogo.setAttribute("class", "posa");
htmllogo.setAttribute("id", "htmllogo");
body.appendChild(htmllogo);
htmllogo.style.width = "100px";
htmllogo.style.left = "633px";
htmllogo.style.top = "350px";
htmllogo.style.zIndex = "4";
$("#heading").fadeOut(0);
$("#htmllogo").fadeOut(0);
setTimeout(function () { $("#heading").fadeIn(1000) }, 2000);
setTimeout(function () { $("#htmllogo").fadeIn(1000) }, 4000);
setTimeout(function () { $("#heading").fadeOut(1000) }, 6000);
setTimeout(function () { $("#htmllogo").fadeOut(1000) }, 6000)*/

//end
//end

var x;
var x2;
var buttonlock = false;
function createmenuitem(name, filename, type, value, width, height, left, top, pagex, pagey, clas, onclick, lsize, lsizeposx, lsizeposy, size, shiftdirection, action, menuitem) {
  eval("var " + name + "=document.createElement(type)");
  if (type === "img") {
    if (menuitem != false) {
      eval(name).setAttribute("src", "/imgs/menuimgs/" + filename + ".png")
    } else {
      eval(name).setAttribute("src", "/imgs/" + filename + ".png")
    };
    eval(name).setAttribute("draggable", "false");
    eval(name).style.width = width + "px";
    if (height != undefined) { eval(name).style.height = height + "px" };
  };
  if (type === "h1" || type === "h2" || type === "h3" || type === "p1" || type === "p2" || type === "p3") {
    eval(name).innerHTML = value;
    eval(name).style.fontSize = size;
  };
  eval(name).setAttribute("class", clas);
  eval(name).setAttribute("id", name);
  eval(name).setAttribute("draggable", "false");
  eval(name).style.left = pagex * 1366 + left + "px";
  eval(name).style.top = pagey * 768 + top + "px";
  eval("body.appendChild(" + name + ")");
  if (lsize != false) {
    eval(name).onmouseover = function () {
      eval(name).style.width = lsize + "px";
      eval(name).style.left = lsizeposx + "px";
    };
    eval(name).onmouseout = function () {
      eval(name).style.width = width + "px";
      eval(name).style.left = left + "px";
    };
  };
  eval(name).onmousedown = function () {
    if (onclick === true) {
      if (buttonlock === false) {
        eval(name).style.filter = "brightness(70%)"
      }
    }
  };
  eval(name).onclick = function () {
    if (buttonlock === false) {
      if (onclick === true) {
        eval(name).style.filter = "brightness(100%)";
        eval(name).style.width = width + "px";
        eval(name).style.left = left + "px";
        eval(action);
        if (shiftdirection != undefined && shiftdirection != false) {
          buttonlock = true;
          if (shiftdirection === "up") { x = "+=768"; x2 = "top" };
          if (shiftdirection === "down") { x = "-=768"; x2 = "top" };
          if (shiftdirection === "left") { x = "+=1366"; x2 = "left" };
          if (shiftdirection === "right") { x = "-=1366"; x2 = "left" };
          setTimeout(function () {
            eval("$(play).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(entersettings).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(info).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(back1).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(back2).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(back3).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(back4).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(savesloth).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss1).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss2).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss3).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss4).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss1h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss2h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss3h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss4h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(gss1h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(gss2h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(gss3h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(gss4h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss1nm).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss2nm).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss3nm).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ss4nm).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(ssinfo).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settingsback).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settingsb1).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settingsb2).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settingsb3).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settingsb4).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settings1h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settings2h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settings3h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(settings4h).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(start).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(deleteb).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            eval("$(plyrskin).animate({ " + x2 + ": (x) }, 1000),{easing:'swing'}");
            setTimeout(function () { buttonlock = false }, 1100)
          }, 200);
        }
      }
    }
  };
  return document.getElementById(name);
};
var c = false;
//setTimeout(function () {
cover.style.zIndex = "-2";
cover.style.opacity = "0";
//body.removeChild(heading);
//body.removeChild(htmllogo);
let menu = document.createElement("script");
menu.setAttribute("src", "/start/menu.js");
body.appendChild(menu);
//}, 8000);