function addhealth(amount){

};
function addxp(amount){

};
function addfood(amount){

};
function addwater(amount){

};