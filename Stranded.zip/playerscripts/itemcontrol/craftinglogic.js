function showcmenu() {

};
/*
knife vine=3 fiber 2000
6 fiber=rope 2500
9 fiber=cloth 3000
2 stick+8 rope=bow 4500
4 stick+2 rope=fishingrod 3000
2 stick+rope+rock=stonepickaxe 3000
2 stick+rope+sharprock=stoneaxe 3000
10 wood+4 rope=workbench 5000
workbench 20 wood+30 rock=forge 4000
forge 4 iron+4 wood=metal 4000
forge 4 iron+coke=2 metal 1000
workbench 3 wood+3 rope+4 metal=metalpickaxe 8000
workbench 3 wood+3 rope+8 metal=metalaxe 8000
workbench 3 wood+2 rope+5 metal=metalknife 7000
workbench 2 wood+4 rope+4 metal=metalbow 8000
workbench 20 metal+40 rock=metalforge 12000
metalforge 4 black coal+10 wood=2 coke 7500
metalforge 4 black coal+coke=3 coke 3500
metalforge 15 metal+2 coke=solidmetal 6000
workbench 25 obsidian+15 solidmetal=obsidianworkbench 1200
obsidianworkbench 10 solidmetal+10 obsidian=obsidianpickaxe 10000
obsidianworkbench 10 solidmetal+15 obsidian=obsidianaxe 10000
obsidianworkbench 5 solidmetal+7 obsidian=obsidianknife 10000
*/