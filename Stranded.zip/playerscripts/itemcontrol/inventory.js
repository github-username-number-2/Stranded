var selectedslot = undefined;
var ssitem = "blank";
var itemlock = false;
var hb = document.createElement("img");
hb.setAttribute("src", "/imgs/playerstatimgs/inventoryhb.png");
hb.setAttribute("draggable", "false");
hb.setAttribute("class", "posa");
hb.style.width = "260px";
hb.style.left = "553px";
hb.style.top = "880px";
hb.style.zIndex = "5";
hb.style.opacity = "0.8";
body.appendChild(hb);
var hbtime = 0, hbup = false, hbint;
function raisehb() {
  hbtime = 300;
  if (!hbup) {
    hbup = true;
    $(hb).animate({
      top: "680px"
    }, 450);
    hbint = setInterval(function () {
      hbtime -= 15;
      if (hbtime <= 0) {
        clearInterval(hbint); hbup = false;
        $(hb).animate({ top: "+=200px" }, 450);
      }
    }, 200)
  }
};
function setss(slot) {
  switch (slot) {
    case 1:
      if (selectedslot != 1) {
        ssitem = inventory[0].substr(0, inventory[0].indexOf(","));
        selectedslot = 1;
      } else { selectedslot = undefined; ssitem = "blank" }
      break;
    case 2:
      if (selectedslot != 2) {
        ssitem = inventory[1].substr(0, inventory[1].indexOf(","));
        selectedslot = 2;
      } else { selectedslot = undefined; ssitem = "blank" }
      break;
    case 3:
      if (selectedslot != 3) {
        ssitem = inventory[2].substr(0, inventory[2].indexOf(","));
        selectedslot = 3;
      } else { selectedslot = undefined; ssitem = "blank" }
      break;
    case 4:
      if (selectedslot != 4) {
        ssitem = inventory[3].substr(0, inventory[3].indexOf(","));
        selectedslot = 4;
      } else { selectedslot = undefined; ssitem = "blank" }
      break;
  }
};
function saveinv() {
  setsave("inventory", JSON.stringify(inventory), 3)
};
var itemg1 = ["bow", "stone pickaxe", "stone axe", "metal pickaxe", "metal axe", "metal knife", "metal bow", "obsidian pickaxe", "obsidian axe", "obsidian knife", "solid metal bow"];
var itemg2 = ["rock", "sharp rock", "vine", "fiber", "sapling", "wood", "stick", "jungle sapling"];
var irarity1 = ["bow", "rock", "sharp rock", "vine", "fiber", "stone pickaxe", "stone axe", "sapling", "wood", "stick", "jungle sapling"];
var irarity2 = ["iron", "metal pickaxe", "metal axe", "metal knife", "black coal", "metal bow"];
var irarity3 = ["obsidian", "obsidian pickaxe", "obsidian axe", "obsidian knife", "solid metal bow"];
function additem(item, count, remove) {
  var added = undefined, added2 = undefined, arinotif = false;
  if (!remove) {
    if (itemg1.includes(item)) {
      for (let a = 0; a < inventory.length; a++) {
        if (inventory[a] === "blank") {
          inventory[a] = item + ",1"; added = true; break
        } else if (a === 9) {
          added = false; arinot("if")
        }
      }
    } else {
      for (let a = 0; a < inventory.length; a++) {
        var slot = inventory[a].substr(0, inventory[a].indexOf(","));
        var itemc = parseInt(inventory[a].substr(inventory[a].indexOf(",") + 1));
        if (slot === item && itemc + count <= 60) {
          inventory[a] = item + "," + (parseInt(inventory[a].substr(inventory[a].indexOf(",") + 1)) + count); added = true; break
        } else if (slot === item && itemc + count >= 60) {
          inventory[a] = item + "," + "60";
          if (60 - itemc === 0) {
            added = false
          } else { added2 = true }; arinotif = true; break
        }
      };
      if (added2 === true || added === undefined) {
        for (let a = 0; a < inventory.length; a++) {
          if (inventory[a] === "blank") {
            if (added2 === true) {
              inventory[a] = item + "," + count; added = true; break
            } else {
              inventory[a] = item + "," + count; added = true; break
            }
          } else if (a === 9 && added2 === undefined) {
            added = false; arinotif = true
          } else if (a === 9 && added2 === true) {
            count = 60 - itemc;
          }
        }
      };
    };
    saveinv();
    if (irarity1.includes(item) && added) {
      arinot("a", item.replace(" ", "&nbsp"), count)
    } else if (irarity2.includes(item) && added) {
      arinot("a", item.replace(" ", "&nbsp"), count, "#ada02b")
    } else if (irarity3.includes(item) && added) {
      arinot("a", item.replace(" ", "&nbsp"), count, "#cc00ff")
    }
  } else {
    if (irarity1.includes(item)) {
      arinot("r", item.replace(" ", "&nbsp"), count)
    } else if (irarity2.includes(item)) {
      arinot("r", item.replace(" ", "&nbsp"), count, "#ada02b")
    } else {
      arinot("r", item.replace(" ", "&nbsp"), count, "#cc00ff")
    }
  };
  if (arinotif) { arinot("if") }
};
/*
0 -water
1 *grassdirt
2 *sand
3 *dirt
4 rock
5 tree
6 berrybush
7 vinebush
8 ironrock
9 ironrocksand
! rock sand
@ mushrooms
# fireout
s stickssand
d sticksdirt
/ fireoutdirt
l fireoutsand
^ *largetreetop
[ largetreebottom
j *junglegrass
b -storageboxgrass
S -storageboxjunglegrass
f -freshwater
R *rockwater
h *rocksaltwater
*/