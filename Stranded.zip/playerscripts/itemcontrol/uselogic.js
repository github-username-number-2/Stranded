let useif = document.createElement("script");
useif.setAttribute("src", "/playerscripts/itemcontrol/useitemfunctions.js");
body.appendChild(useif);