let inv = document.createElement("script");
inv.setAttribute("src", "/playerscripts/itemcontrol/inventory.js");
body.appendChild(inv);
let intf = document.createElement("script");
intf.setAttribute("src", "/playerscripts/itemcontrol/interactfunctions.js");
body.appendChild(intf);
var p2, int;
setInterval(function () { check() }, 50)
function check() {
  p2 = p;
  if ($("#player").queue().length == 0 && q === false) {
    if (p2 != null) { p.style.opacity = "0.85"; int = true }
  }
  else { if (p2 != null) { p.style.opacity = "0.6"; int = false } }
};
setInterval(function () {
  if (int === true) { playertarget.style.zIndex = "-1" }
  else { playertarget.style.zIndex = "2" }
}, 50);
var lackreqtool = document.createElement("h2");
lackreqtool.setAttribute("class", "posa");
lackreqtool.innerHTML = "You lack the required tool.";
lackreqtool.style.color = "#ff0000";
lackreqtool.style.left = "350px";
lackreqtool.style.top = "300px";
body.appendChild(lackreqtool);
lackreqtool.style.opacity = "0";
lackreqtool.style.zIndex = "3";
var lrtvar = 0;
function lrt() {
  lrtvar = 0.5;
  var lrtint = setInterval(function () {
    lackreqtool.style.opacity = lrtvar.toString(); lrtvar -= 0.02;
    if (lrtvar <= 0) { clearInterval(lrtint) }
  }, 50)
};
var cdot = document.createElement("h2");
cdot.setAttribute("class", "posa");
cdot.innerHTML = "You can't do that.";
cdot.style.color = "#ff0000";
cdot.style.left = "350px";
cdot.style.top = "300px";
body.appendChild(cdot);
cdot.style.opacity = "0";
cdot.style.zIndex = "3";
var cdtvar = 0;
function cdt() {
  cdtvar = 0.5;
  var cdtint = setInterval(function () {
    cdot.style.opacity = cdtvar.toString(); cdtvar -= 0.02;
    if (cdtvar <= 0) { clearInterval(cdtint); }
  }, 50)
};
var cint = document.createElement("h2");
cint.setAttribute("class", "posa");
cint.innerHTML = "You can't interact with this.";
cint.style.color = "#ff0000";
cint.style.left = "350px";
cint.style.top = "300px";
body.appendChild(cint);
cint.style.opacity = "0";
cint.style.zIndex = "3";
var civar = 0;
function ci() {
  civar = 0.5;
  var ciint = setInterval(function () {
    cint.style.opacity = civar.toString(); civar -= 0.02;
    if (civar <= 0) { clearInterval(ciint); }
  }, 50)
};
function getblock(coords) {
  if (coords === undefined) {
    if (facing === "up") { return w[py - 1].substr(px, 1) };
    if (facing === "down") { return w[py + 1].substr(px, 1) };
    if (facing === "left") { return w[py].substr(px - 1, 1) };
    if (facing === "right") { return w[py].substr(px + 1, 1) };
  } else {
    var gbpx = coords.substr(1, coords.indexOf("y") - 1);
    var gbpy = coords.substr(coords.indexOf("y") + 1);
    return w[gbpy].substr(gbpx, 1)
  }
};
var ix, ixl;
var iy, iyl;
function setblock(block, otherb, otherbxy) {
  if (otherb === undefined) {
    ix = p.id.substr(1, p.id.indexOf("y") - 1);
    iy = p.id.substr(p.id.indexOf("y") + 1);
    w[iy] = w[iy].substr(0, ix) + block + w[iy].substr(parseInt(ix) + 1);
  } else {
    ix = p.id.substr(1, p.id.indexOf("y") - 1);
    iy = p.id.substr(p.id.indexOf("y") + 1);
    w[iy] = w[iy].substr(0, ix) + block + w[iy].substr(parseInt(ix) + 1);
    if (otherbxy = "up") { iy = parseInt(p.id.substr(p.id.indexOf("y") + 1)) - 1 }
    else if (otherbxy = "down") { iy = parseInt(p.id.substr(p.id.indexOf("y") + 1)) }
    else if (otherbxy = "left") { ix = parseInt(p.id.substr(1, p.id.indexOf("y") - 1)) - 1 }
    else if (otherbxy = "right") { ix = parseInt(p.id.substr(1, p.id.indexOf("y") - 1)) + 1 }
    w[iy] = w[iy].substr(0, ix) + otherb + w[iy].substr(parseInt(ix) + 1);
  }
};
function checkinteract() {
  switch (getblock()) {
    case "0": interact("0"); break;
    case "1": interact("1"); break;
    case "2": ci(); break;
    case "3": ci(); break;
    case "4": interact("4"); break;
    case "5": interact("5"); break;
    case "6": interact("6"); break;
    case "7": interact("7"); break;
    case "8": interact("8"); break;
    case "9": interact("9"); break;
    case "!": interact("!"); break;
    case "@": interact("@"); break;
    case "#": interact("#"); break;
    case "s": interact("s"); break;
    case "d": interact("d"); break;
    case "/": interact("/"); break;
    case "l": interact("l"); break;
    case "^": ci(); break;
    case "[": interact("["); break;
    case "j": interact("j"); break;
    case "b": interact("b"); break;
    case "S": interact("S"); break;
    case "f": interact("f"); break;
    case "R": ci(); break;
    case "h": ci(); break;
    case "o": interact("o"); break;
    case "O": interact("O"); break;
    case "c": interact("c"); break;
    case "C": interact("C"); break;
  };
};
/*
0 water
1 grassdirt
2 sand
3 dirt
4 rock
5 tree
6 berrybush
7 vinebush
8 ironrock
9 ironrocksand
! rock sand
@ mushrooms
# fireout
s stickssand
d sticksdirt
/ fireoutdirt
l fireoutsand
^ largetreetop
[ largetreebottom
j junglegrass
b storageboxgrass
S storageboxjunglegrass
f freshwater
R rockwater
h rocksaltwater
*/