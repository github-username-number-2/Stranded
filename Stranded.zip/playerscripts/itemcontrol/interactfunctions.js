var action;
var ssitemg1 = ["blank", "rock", "stone pickaxe", "metal pickaxe", "obsidian pickaxe"];
var ssitemg2 = ["blank", "shar prock", "stone axe", "metal axe", "obsidian axe"];
var ssitemg3 = ["blank", "sharp rock", "metal knife", "obsidian knife"];
var ssitemg4 = ["stone pickaxe", "metal pickaxe", "obsidian pickaxe"];
var ssitemg5 = ["metal pickaxe", "obsidian pickaxe"];
function interact(block) {
  switch (block) {
    case "0":
      if (ssi === "raft") { end() } else { lrt() }; break;
    case "1":
      if (ssitem === "sapling") { itimer(3000, "createtree();additem('sapling',1,true)") } else { lrt() }; break;
    case "4":
      if (ssitemg1.includes(ssitem)) { harvestresource("4", ssitem) }
      else { lrt() }; break;
    case "5":
      if (ssitemg2.includes(ssitem)) { harvestresource("5", ssitem) }
      else { lrt() }; break;
    case "6":
      if (ssitem === "blank") { harvestresource("6", ssitem) }
      else { lrt() }; break;
    case "7":
      if (ssitemg3.includes(ssitem)) { harvestresource("7", ssitem) }
      else { lrt() }; break;
    case "8":
      if (ssitemg1.includes(ssitem)) { harvestresource("8", ssitem) }
      else { lrt() }; break;
    case "9":
      if (ssitemg1.includes(ssitem)) { harvestresource("9", ssitem) }
      else { lrt() }; break;
    case "!":
      if (ssitemg1.includes(ssitem)) { harvestresource("!", ssitem) }
      else { lrt() }; break;
    case "@":
      if (ssitem === "blank") { harvestresource("@", ssitem) }
      else { lrt() }; break;
    case "#":
      if (ssitem === "blank") { harvestresource("#", ssitem) }
      else { lrt() }; break;
    case "s":
      if (ssitem === "blank") { harvestresource("s", ssitem) }
      else { lrt() }; break;
    case "d":
      if (ssitem === "blank") { harvestresource("d", ssitem) }
      else { lrt() }; break;
    case "/":
      if (ssitem === "blank") { harvestresource("/", ssitem) }
      else { lrt() }; break;
    case "l":
      if (ssitem === "blank") { harvestresource("l", ssitem) }
      else { lrt() }; break;
    case "[":
      if (ssitemg2.includes(ssitem)) { harvestresource("[", ssitem) }
      else { lrt() }; break;
    case "b":
      break;
    case "S":
      break;
    case "f": itimer(1000, "addwater(25)"); break;
    case "o":
      if (ssitemg5.includes(ssitem)) { harvestresource("o", ssitem) }
      else { lrt() }; break;
    case "O":
      if (ssitemg5.includes(ssitem)) { harvestresource("O", ssitem) }
      else { lrt() }; break;
    case "c":
      if (ssitemg4.includes(ssitem)) { harvestresource("c", ssitem) }
      else { lrt() }; break;
    case "C":
      if (ssitemg4.includes(ssitem)) { harvestresource("C", ssitem) }
      else { lrt() }; break;
    case "j":
      if (ssitem === "jungle sapling") {
        if (facing != "down" && getblock(p.id.substr(0, p.id.indexOf("y") + 1) + (parseInt(p.id.substr(p.id.indexOf("y") + 1)) - 1)) === "j") {
          itimer(3000, "createjungletree();additem('jungle sapling',1,true)")
        } else { cdt() }
      } else { lrt() }; break;

  }
};
function itimer(itime, action) {
  itemlock = true;
  setTimeout(function () {
    p.setAttribute("src", "/imgs/ib.png");
    itemlock = false;
    eval(action);
  }, itime);
};
function setitr(itime, item, rarity, xp, brk) {
  itimer(itime, "additem('" + item + "'," + rarity + ");addxp(" + xp + ");if(int==true&&" + brk + "==1){breakblock()}")
};
function setrnvals() {
  dr = rn(1, 15); if (dr === 15) { dr = 1 };
  r1 = rn(1, 5); if (r1 < 5) { r1 = 1 } else { r1 = 2 };
  r2 = rn(1, 4); if (r2 < 3) { r2 = 1 } else { r2 = 2 };
  r3 = rn(1, 5); if (r3 < 2) { r3 = 1 } else if (r3 < 5) { r3 = 2 } else { r3 = 3 };
  r4 = rn(1, 5); if (r4 < 2) { r4 = 3 } else if (r4 < 5) { r4 = 4 } else { r4 = 5 };
  hrnum = rn(1, 10000);
};
function hrrock(blocknum, tool) {
  setrnvals();
  if (tool === "blank") {
    if (hrnum < 6000) { setitr(3000, "rock", r1, 1) }
    else if (hrnum < 9750) { setitr(3000, "sharp rock", r1, 1) }
    else if (hrnum < 9999) { setitr(3000, "iron", r1, 1) }
    else if (hrnum === 10000) { setitr(3000, "obsidian", r1, 1) }
  };
  if (tool === "rock") {
    if (hrnum < 6000) { setitr(2500, "rock", r2, 1) }
    else if (hrnum < 9700) { setitr(2500, "sharp rock", r2, 1) }
    else if (hrnum < 9998) { setitr(2500, "iron", r2, 1) }
    else if (hrnum < 10000) { setitr(2500, "obsidian", r1, 1) }
  };
  if (tool === "stone pickaxe") {
    if (hrnum < 6000) { setitr(2000, "rock", r2, 1) }
    else if (hrnum < 9700) { setitr(2000, "sharp rock", r2, 1) }
    else if (hrnum < 9998) { setitr(2000, "iron", r2, 1) }
    else if (hrnum < 10000) { setitr(2000, "obsidian", r2, 1) }
  };
  if (tool === "metal pickaxe") {
    if (hrnum < 4500) { setitr(1500, "rock", r3, 1) }
    else if (hrnum < 8500) { setitr(1300, "sharp rock", r3, 1) }
    else if (hrnum < 9997) { setitr(1300, "iron", r3, 1) }
    else if (hrnum < 10000) { setitr(1300, "obsidian", r2, 1) }
  };
  if (tool === "obsidian pickaxe") {
    if (hrnum < 4000) { setitr(700, "rock", r4, 1) }
    else if (hrnum < 8000) { setitr(700, "sharp rock", r4, 1) }
    else if (hrnum < 9992) { setitr(700, "iron", r3, 1) }
    else if (hrnum < 10000) { setitr(700, "obsidian", r2), 1 }
  };
};
function hrironrock(blocknum, tool) {
  setrnvals();
  if (tool === "blank") {
    if (hrnum < 4500) { setitr(3500, "rock", r1, 2) }
    else if (hrnum < 8500) { setitr(3500, "sharp rock", r1, 2) }
    else if (hrnum < 9999) { setitr(3500, "iron", r1, 2) }
    else if (hrnum === 10000) { setitr(3500, "obsidian", r1, 2) }
  };
  if (tool === "rock") {
    if (hrnum < 4000) { setitr(3000, "rock", r2, 2) }
    else if (hrnum < 8000) { setitr(3000, "sharp rock", r2, 2) }
    else if (hrnum < 9998) { setitr(3000, "iron", r1, 2) }
    else if (hrnum < 10000) { setitr(3000, "obsidian", r1, 2) }
  };
  if (tool === "stone pickaxe") {
    if (hrnum < 4000) { setitr(2500, "rock", r2, 2) }
    else if (hrnum < 8000) { setitr(2500, "sharp rock", r2, 2) }
    else if (hrnum < 9998) { setitr(2500, "iron", r2, 2) }
    else if (hrnum < 10000) { setitr(2500, "obsidian", r1, 2) }
  };
  if (tool === "metal pickaxe") {
    if (hrnum < 3200) { setitr(1800, "rock", r3, 2) }
    else if (hrnum < 6400) { setitr(1800, "sharp rock", r3, 2) }
    else if (hrnum < 9997) { setitr(1800, "iron", r2, 2) }
    else if (hrnum < 10000) { setitr(1800, "obsidian", r2, 2) }
  };
  if (tool === "obsidian pickaxe") {
    if (hrnum < 2000) { setitr(700, "rock", r3, 2) }
    else if (hrnum < 4000) { setitr(700, "sharp rock", r3, 2) }
    else if (hrnum < 9992) { setitr(700, "iron", r4, 2) }
    else if (hrnum < 10000) { setitr(700, "obsidian", r2, 2) }
  };
};
function hrblackcoal(blocknum, tool) {
  setrnvals();
  if (tool === "stone pickaxe") {
    if (hrnum < 4000) { setitr(3000, "rock", r2, 4) }
    else if (hrnum < 8000) { setitr(3000, "sharp rock", r2, 4) }
    else if (hrnum < 10000) { setitr(3000, "black coal", r1, 4) }
  };
  if (tool === "metal pickaxe") {
    if (hrnum < 3500) { setitr(2000, "rock", r3, 4) }
    else if (hrnum < 7000) { setitr(2000, "sharp rock", r3, 4) }
    else if (hrnum < 10000) { setitr(2000, "black coal", r2, 4) }
  };
  if (tool === "obsidian pickaxe") {
    if (hrnum < 2500) { setitr(1000, "rock", r3, 4) }
    else if (hrnum < 5000) { setitr(1000, "sharp rock", r3, 4) }
    else if (hrnum < 10000) { setitr(1000, "black coal", r3, 4) }
  };
};
function hrobsidian(blocknum, tool) {
  setrnvals();
  if (tool === "metal pickaxe") {
    if (hrnum < 4000) { setitr(5000, "rock", 1, 4) }
    else if (hrnum < 8000) { setitr(5000, "sharp rock", 1, 4) }
    else if (hrnum < 10000) { setitr(5000, "obsidian", 1, 4) }
  };
  if (tool === "obsidian pickaxe") {
    if (hrnum < 2500) { setitr(3000, "rock", r1, 4) }
    else if (hrnum < 5000) { setitr(3000, "sharp rock", r1, 4) }
    else if (hrnum < 10000) { setitr(3000, "obsidian", r3, 4) }
  };
};
var hrnum, r1, r2, r3, r4, dr1, dr2, dr3, dr4;
function harvestresource(blocknum, tool) {
  setrnvals();
  if (blocknum === "4") {
    hrrock(blocknum, tool);
  };
  if (blocknum === "5") {
    if (tool === "blank") {
      if (hrnum < 4500) { setitr(2000, "stick", r2, 1) }
      else if (hrnum < 6000) { setitr(2000, "wood", r1, 1) }
      else if (hrnum < 10000) { setitr(2000, "sapling", r3, 1) }
    };
    if (tool === "sharp rock") {
      if (hrnum < 4000) { setitr(1700, "stick", r2, 1) }
      else if (hrnum < 6000) { setitr(1700, "wood", r2, 1) }
      else if (hrnum < 10000) { setitr(1700, "sapling", r2, 1) }
    };
    if (tool === "stone axe") {
      if (hrnum < 4000) { setitr(1500, "stick", r2, 1, rn(1, 12)) }
      else if (hrnum < 8000) { setitr(1500, "wood", r2, 1, rn(1, 12)) }
      else if (hrnum < 10000) { setitr(1500, "sapling", r2, 1) }
    };
    if (tool === "metal axe") {
      if (hrnum < 2000) { setitr(1200, "stick", r2, 1, rn(1, 11)) }
      else if (hrnum < 9700) { setitr(1200, "wood", r3, 1, rn(1, 11)) }
      else if (hrnum < 10000) { setitr(1200, "sapling", r1, 1) }
    };
    if (tool === "obsidian axe") {
      if (hrnum < 1800) { setitr(700, "stick", r2, 1, rn(1, 10)) }
      else if (hrnum < 9900) { setitr(700, "wood", r3, 1, rn(1, 10)) }
      else if (hrnum < 10000) { setitr(700, "sapling", r1, 1) }
    };
  };
  if (blocknum === "6") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "7") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "8") {
    hrironrock(blocknum, tool);
  };
  if (blocknum === "9") {
    hrironrock(blocknum, tool);
  };
  if (blocknum === "!") {
    hrrock(blocknum, tool)
  };
  if (blocknum === "@") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "#") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "s") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "d") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "l") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "/") {
    if (tool === "blank") {

    }
  };
  if (blocknum === "[") {
    if (tool === "blank") {
      setitr(2500, "sapling", r1, 1)
    };
    if (tool === "metal axe") {
      if (hrnum < 2000) { setitr(1200, "stick", r2, 1, rn(1, 20)) }
      else if (hrnum < 9700) { setitr(1200, "wood", r4, 1, rn(1, 20)) }
      else if (hrnum < 10000) { setitr(1200, "sapling", r1, 1) }
    };
    if (tool === "obsidian axe") {
      if (hrnum < 1800) { setitr(700, "stick", r3, 1, rn(1, 15)) }
      else if (hrnum < 9900) { setitr(700, "wood", r4, 1, rn(1, 15)) }
      else if (hrnum < 10000) { setitr(700, "sapling", r1, 1) }
    };
  };
  if (blocknum === "o") {
    hrobsidian(blocknum, tool)
  };
  if (blocknum === "O") {
    hrobsidian(blocknum, tool)
  };
  if (blocknum === "c") {
    hrblackcoal(blocknum, tool)
  };
  if (blocknum === "C") {
    hrblackcoal(blocknum, tool)
  };
};
/*
0 -water
1 *grassdirt
2 *sand
3 *dirt
4 rock 1
5 tree
6 berrybush
7 vinebush
8 ironrock
9 ironrocksand
! rock sand
@ mushrooms
# fireout
s stickssand
d sticksdirt
/ fireoutdirt
l fireoutsand
^ *largetreetop
[ largetreebottom
j *junglegrass
b -storageboxgrass
S -storageboxjunglegrass
f -freshwater
R *rockwater
h *rocksaltwater
*/