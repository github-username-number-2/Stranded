loadpsaves();
var playertarget = document.createElement("img");
playertarget.setAttribute("src", "/imgs/playertarget.png");
playertarget.setAttribute("id", "playertarget");
playertarget.classList.add("posa");
playertarget.style.width = "39px";
playertarget.setAttribute("draggable", "false");
playertarget.style.zIndex = "1";
body.appendChild(playertarget);
var player = document.createElement("img");
player.setAttribute("src", "/imgs/skins/" + eval("playerskin" + saveslot) + "/left.png");
player.setAttribute("id", "player");
player.classList.add("posa");
player.style.width = "52px";
player.setAttribute("draggable", "false");
player.style.zIndex = "2";
body.appendChild(player);
playertarget.style.left = (px * 52 + 37).toString() + "px";
playertarget.style.top = (py * 52 + 180).toString() + "px";
player.style.left = (px * 52 + 33).toString() + "px";
player.style.top = (py * 52 + 170).toString() + "px";
var movearray = [];
var ma;
var nfacing;
setInterval(function () {
  if (ma != undefined) {
    nfacing = ma;
  }
}, 50);
function setplayerpos(speed) {
  $("#player").animate({
    left: (px * 52 + 33),
    top: (py * 52 + 170)
  }, speed);
  playertarget.style.left = (px * 52 + 37).toString() + "px";
  playertarget.style.top = (py * 52 + 180).toString() + "px";
  if (speed != 0) {
    movearray.push(facing);
    setTimeout(function () {
      ma = movearray[0];
      if (ma != undefined) {
        player.setAttribute("src", "/imgs/skins/" + eval("playerskin" + saveslot) + "/" + ma + ".png");
        movearray.shift();
      }
    }, $("#player").queue().length * 500 - 700)
  }
};
let playercontrols = document.createElement("script");
playercontrols.setAttribute("src", "/playerscripts/playercontrols.js");
let playerstats = document.createElement("script");
playerstats.setAttribute("src", "/playerscripts/playerinterface.js");
let coordinates = document.createElement("script");
coordinates.setAttribute("src", "/playerscripts/coordinates.js");
let stats = document.createElement("script");
stats.setAttribute("src", "/playerscripts/playerstatslogic.js");
let clogic = document.createElement("script");
clogic.setAttribute("src", "/playerscripts/itemcontrol/craftinglogic.js");
let plvl = document.createElement("script");
plvl.setAttribute("src", "/playerscripts/playerlevels.js");
let acm = document.createElement("script");
acm.setAttribute("src", "/playerscripts/achivements.js");
body.appendChild(playercontrols);
body.appendChild(playerstats);
body.appendChild(coordinates);
body.appendChild(stats);
body.appendChild(clogic);
body.appendChild(plvl);
body.appendChild(acm);