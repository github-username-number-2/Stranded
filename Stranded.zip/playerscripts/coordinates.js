var coordx = document.createElement("p");
coordx.setAttribute("class", "ps2p");
coordx.style.left = "10px";
coordx.style.top = "155px";
coordx.style.zIndex = "4";
var coordy = document.createElement("p");
coordy.setAttribute("class", "ps2p");
coordy.style.left = "10px";
coordy.style.top = "170px";
coordy.style.zIndex = "4";
var coordwx = document.createElement("p");
coordwx.setAttribute("class", "ps2p");
coordwx.style.left = "10px";
coordwx.style.top = "185px";
coordwx.style.zIndex = "4";
var coordwy = document.createElement("p");
coordwy.setAttribute("class", "ps2p");
coordwy.style.left = "10px";
coordwy.style.top = "200px";
coordwy.style.zIndex = "4";
body.appendChild(coordx);
body.appendChild(coordy);
body.appendChild(coordwx);
body.appendChild(coordwy);
var int = false;
if (showcoords === "true") {
  coordx.innerHTML = "x: " + px;
  coordy.innerHTML = "y: " + py;
  coordwx.innerHTML = "wx: " + wx;
  coordwy.innerHTML = "wy: " + wy;
};
setTimeout(function () {
  setInterval(function () {
    if (showcoords === "true") {
      if (px < 2 && py < 2) {
        coordx.style.opacity = "0.3";
        coordy.style.opacity = "0.3" + py;
        coordwx.style.opacity = "0.3" + wx;
        coordwy.style.opacity = "0.3" + wy;
      } else {
        if (int === true) {
          coordx.style.opacity = "1";
          coordy.style.opacity = "1" + py;
          coordwx.style.opacity = "1" + wx;
          coordwy.style.opacity = "1" + wy;
        }
      };
      if (int === true) {
        coordx.innerHTML = "x: " + px;
        coordy.innerHTML = "y: " + py;
        coordwx.innerHTML = "wx: " + wx;
        coordwy.innerHTML = "wy: " + wy;
      };
    };
    if (px > 22 && py < 2) {
      time2.style.opacity = "0.3";
    } else {
      time2.style.opacity = "1";
    };
    if (px > 8 && px < 16 && py > 8) {
      hb.style.opacity = "0.2"
    } else {
      hb.style.opacity = "0.8"
    };
  }, 100)
}, 1000);