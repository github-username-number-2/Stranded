var back = document.createElement("img");
back.setAttribute("src", "/imgs/playerstatimgs/back.png");
back.setAttribute("draggable", false);
back.classList.add("posa");
body.appendChild(back);
back.style.width = "1367px";
back.style.height = "160px";
back.style.top = "0px";
back.style.left = "0px";
var settingsb = document.createElement("img");
settingsb.setAttribute("src", "/imgs/playerstatimgs/settingsb.png");
settingsb.setAttribute("draggable", false);
settingsb.classList.add("posa");
body.appendChild(settingsb);
settingsb.style.width = "100px";
settingsb.style.height = "100px";
settingsb.style.top = "30px";
settingsb.style.left = "1246px";
var inventoryb = document.createElement("img");
inventoryb.setAttribute("src", "/imgs/playerstatimgs/inventoryb.png");
inventoryb.setAttribute("draggable", false);
inventoryb.classList.add("posa");
body.appendChild(inventoryb);
inventoryb.style.width = "100px";
inventoryb.style.height = "100px";
inventoryb.style.top = "30px";
inventoryb.style.left = "1126px";
var mapb = document.createElement("img");
mapb.setAttribute("src", "/imgs/playerstatimgs/mapb.png");
mapb.setAttribute("draggable", false);
mapb.classList.add("posa");
body.appendChild(mapb);
mapb.style.width = "100px";
mapb.style.height = "100px";
mapb.style.top = "30px";
mapb.style.left = "1006px";
var craftingb = document.createElement("img");
craftingb.setAttribute("src", "/imgs/playerstatimgs/craftingb.png");
craftingb.setAttribute("draggable", false);
craftingb.classList.add("posa");
body.appendChild(craftingb);
craftingb.style.width = "100px";
craftingb.style.height = "100px";
craftingb.style.top = "30px";
craftingb.style.left = "886px";
var aril = document.createElement("p");
aril.setAttribute("class", "posa");
aril.style.fontSize = "12px";
aril.style.zIndex = "3";
aril.style.left = "15px";
aril.style.top = "300px";
body.appendChild(aril);
var ararray = [];
function arinot(ar, item, num, color) {
  if (color === undefined) { color = "#000000" };
  if (num === undefined) { num = "1&nbsp" };
  if (ar === "a") {
    ararray.push("<span class='ps2p'><span style='color:#0ffc03'>Added</span><br /> " + num + "&nbsp<span style='color:" + color + "'>" + item + "</span></span>");
    aril.innerHTML = ararray.join("<br /><br />");
    setTimeout(function () {
      ararray.shift();
      aril.innerHTML = ararray.join("<br /><br />");
    }, 2000);
  } else if (ar === "r") {
    ararray.push("<span class='ps2p'><span style='color:#e9ed0e'>Removed</span><br /> " + num + "<span style='color:" + color + "'>" + item + "</span></span>");
    aril.innerHTML = ararray.join("<br /><br />");
    setTimeout(function () {
      ararray.shift();
      aril.innerHTML = ararray.join("<br /><br />");
    }, 2000);
  } else if (ar === "l") {
    ararray.push("<span class='ps2p'><span style='color:#00e1ff'>Level&nbspUp!</span>");
    aril.innerHTML = ararray.join("<br /><br />");
    setTimeout(function () {
      ararray.shift();
      aril.innerHTML = ararray.join("<br /><br />");
    }, 2000);
  } else if (ar === "if") {
    ararray.push("<span class='ps2p'><span style='color:#d91c1c'>Inventory&nbspFull</span>");
    aril.innerHTML = ararray.join("<br /><br />");
    setTimeout(function () {
      ararray.shift();
      aril.innerHTML = ararray.join("<br /><br />");
    }, 2000);
  }
};
function showsb() {

};