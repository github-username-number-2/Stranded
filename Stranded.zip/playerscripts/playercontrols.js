var q = false, keydown = false, movelock = true, mvmntspeed = 500;
setTimeout(function () { movelock = false }, 1000);
document.addEventListener('keydown', function (keyd) {
  if (!movelock && !itemlock && !loadlock) {
    if (keydown) { return };
    keydown = true;
    if (keyd.code === "ArrowUp" || keyd.code === "KeyW") {
      facing = "up";
      if (checkformove("up")) {
        if (!loadlock) {
          py -= 1;
          setplayerpos(mvmntspeed)
        };
      } else { world.load("up") };
      cfi(); q = false;
    };
    if (keyd.code === "ArrowDown" || keyd.code === "KeyS") {
      facing = "down";
      if (checkformove("down")) {
        if (!loadlock) {
          py += 1;
          setplayerpos(mvmntspeed)
        };
      } else { world.load("down") };
      cfi(); q = false;
    };
    if (keyd.code === "ArrowLeft" || keyd.code === "KeyA") {
      facing = "left";
      if (checkformove("left")) {
        if (!loadlock) {
          px -= 1;
          setplayerpos(mvmntspeed)
        };
      } else { world.load("left") };
      cfi(); q = false;
    };
    if (keyd.code === "ArrowRight" || keyd.code === "KeyD") {
      facing = "right";
      if (checkformove("right")) {
        if (!loadlock) {
          px += 1;
          setplayerpos(mvmntspeed)
        };
      } else { world.load("right") };
      cfi(); q = false;
    };
    if (keyd.code === "KeyE") {
      if (int) {
        if (typeof p != undefined) {
          p.setAttribute("src", "/imgs/ibd.png")
          checkinteract();
        }
      }
    };
    if (keyd.code === "Digit1") { setss(1); raisehb() };
    if (keyd.code === "Digit2") { setss(2); raisehb() };
    if (keyd.code === "Digit3") { setss(3); raisehb() };
    if (keyd.code === "Digit4") { setss(4); raisehb() };
  };
  if (keyd.code === "KeyQ") {
    q = true;
    movelock = true;
    player.setAttribute("src", "/imgs/skins/" + eval("playerskin" + saveslot) + "/" + nfacing + ".png");
    $(player).clearQueue();
    movearray = [];
    setTimeout(function () {
      px = Math.round((player.style.left.substr(0, player.style.left.indexOf("p")) - 33) / 52)
    }, 400);
    setTimeout(function () {
      py = Math.round((player.style.top.substr(0, player.style.top.indexOf("p")) - 170) / 52)
    }, 400);
    setTimeout(function () {
      movelock = false;
    }, 400);
    setTimeout(function () {
      playertarget.style.left = (px * 52 + 37).toString() + "px";
      playertarget.style.top = (py * 52 + 180).toString() + "px";
    }, 410);
  };
}, false);
setplayerpos(0);
document.addEventListener('keyup', function (keyu) {
  keydown = false;
  if (keyu.code === "KeyE") {
    if (p != undefined) {
      if (!itemlock) {
        p.setAttribute("src", "/imgs/ib.png")
      }
    }
  }
}, false);
function checkformove(direction) {
  if (direction == "up") {
    if (py != 0) {
      var bup = w[py - 1].substr(px, 1);
      if (py - 1 >= 0) { if (bup == "1" || bup == "2" || bup == "3" || bup == "j") { return true } }
    }
  };
  if (direction == "down") {
    if (py != 10) {
      var bup = w[py + 1].substr(px, 1);
      if (py + 1 >= 0) { if (bup == "1" || bup == "2" || bup == "3" || bup == "j") { return true } }
    }
  };
  if (direction == "left") {
    var bup = w[py].substr(px - 1, 1);
    if (px - 1 >= 0) { if (bup == "1" || bup == "2" || bup == "3" || bup == "j") { return true } }
  };
  if (direction == "right") {
    var bup = w[py].substr(px + 1, 1);
    if (px + 1 >= 0) { if (bup == "1" || bup == "2" || bup == "3" || bup == "j") { return true } }
  };
};
var facing, p, t;
function cfi() {
  if (p != undefined) { $(p).finish().css('width', '0px') };
  if (facing === "up") {
    if (py != 0) {
      t = true;
      p = document.getElementById("x" + px.toString() + "y" + (py - 1));
    } else { t = false }
  };
  if (facing === "down") {
    if (py != 10) {
      t = true;
      p = document.getElementById("x" + px.toString() + "y" + (py + 1));
    } else { t = false }
  };
  if (facing === "left") {
    if (px != 0) {
      t = true;
      p = document.getElementById("x" + (px - 1).toString() + "y" + (py));
    } else { t = false }
  };
  if (facing === "right") {
    if (px != 24) {
      t = true;
      p = document.getElementById("x" + (px + 1).toString() + "y" + (py));
    } else { t = false }
  };
  if (t != false) { $(p).animate({ width: "39px" }, 300) };
};
let interactlogic = document.createElement("script");
interactlogic.setAttribute("src", "/playerscripts/itemcontrol/interactlogic.js");
body.appendChild(interactlogic);
let uselogic = document.createElement("script");
uselogic.setAttribute("src", "/playerscripts/itemcontrol/uselogic.js");
body.appendChild(uselogic);
if (autosave === "true") { startsave() };