function addxp(amount){

};
/*
1 8
2 
3
4
5
6
7
8
9
10
11
12
13
14
15
70 288
120 788
1-80 xp=5level+8
80-120 xp=10level-412
*/