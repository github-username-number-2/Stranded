//saveslots
//saveslots
var saveslot = "";
var game = "";

//primary save data
//primary save data
var autosave = "true", showcoords = "false", showwcoords = "false", showmap = "true";
for (let a = 1; a < 5; a++) {
  eval("var datess" + a + "='Empty'");
  eval("var goldss" + a + "=0");
  eval("var ss" + a + "n='Save'+a");
  eval("var playerskinss" + a + "='player'");
  eval("var dayssurvivedss" + a + "=0");
};
//secondary save data
//secondary save data


//tertiary save data
//tertiary save data
var health = 78, food = 96, water = 67, xp = 0;
var wx = 1, wy = 0;
var px = 15, py = 7;
var time = "Day 1<br />9:28";
var gold = 0;
var raining = "false";
var inventory = ["blank", "blank", "blank", "blank", "blank", "blank", "blank", "blank", "blank", "blank"];
function getsave(savename, datatype) {
  if (datatype === 0 || datatype === undefined) {
    return window.localStorage.getItem(savename)
  } else if (datatype === 1) {
    return window.localStorage.getItem(savename + saveslot)
  } else {
    return window.localStorage.getItem(savename + saveslot + game)
  }
};
function setsave(savename, value, datatype) {
  if (datatype === 0 || datatype === undefined) {
    window.localStorage.setItem(savename, value)
  } else if (datatype === 1) {
    window.localStorage.setItem(savename + saveslot, value)
  } else {
    window.localStorage.setItem(savename + saveslot + game, value)
  }
};
function loadsave(savename, variable, datatype, number) {
  if (getsave(savename, datatype) != null) {
    if (number === true) {
      eval(variable + "=parseInt(getsave(savename, datatype))")
    } else {
      eval(variable + "=getsave(savename, datatype)")
    }
  }
};

//primary saves
//primary saves
loadsave("autosave", "autosave", 0, false);
loadsave("showcoords", "showcoords", 0, false);
loadsave("showwcoords", "showwcoords", 0, false);
loadsave("showmap", "showmap", 0, false);
for (let a = 1; a < 5; a++) {
  loadsave("datess" + a, "datess" + a, 0, false);
  loadsave("goldss" + a, "goldss" + a, 0, false);
  loadsave("playerskinss" + a, "playerskinss" + a, 0, false);
};
//primary saves
//primary saves
function loadwsaves() {
  var lwx = 0, lwy = 0;
  for (var lw = 0; lw < 20; lw++) {
    let world;
    if (getsave(eval("'worldx" + lwx + "y" + lwy + saveslot + "'")) != null) {
      world = JSON.parse(getsave(eval("'worldx" + lwx + "y" + lwy + saveslot + "'")));
      eval("worldx" + lwx + "y" + lwy + "=world");
    };
    if (lwx === 3) { lwx = 0; lwy++ } else { lwx++ };
  }
  loadsave("wx", "wx", 3, true);
  loadsave("wy", "wy", 3, true);
  loadsave("time", "time", 3);
  loadsave("raining", "raining", 3);
};
function loadpsaves() {
  loadsave("px", "px", 3, true);
  loadsave("py", "py", 3, true);
  if (getsave("inventory", 3) != null) {
    inventory = JSON.parse(getsave("inventory", 3))
  }
};
eval(decodeURI(atob("aWYod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lIT0nc3RyYW5kZWQtLWxpbHBlZW4ucmVwbC5jbycmJndpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSE9J3N0cmFuZGVkLmxpbHBlZW4ucmVwbC5jbycmJndpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSE9J2djc3RyYW5kZWQucmYuZ2QnKXtkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnaHRtbG1haW4nKS5pbm5lckhUTUw9JzxoMT5FcnJvcjogNDA0IG5vdCBmb3VuZDxoMT4nO3dpbmRvdy5zdG9wKCl9")));
function startsave() {
  setInterval(function () {
    date = new Date();
    date = date.getFullYear() + '/' + date.getMonth() + '/' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
    setsave("date" + saveslot, date);
    setsave("gold" + saveslot, gold);
    setsave("dayssurvived" + saveslot, "dayssurvived" + saveslot);
    if (typeof px != undefined) {
      if (typeof player != undefined) {
        if ($(player).queue().length === 0) {
          setsave("px", px, 3);
          setsave("py", py, 3);
          setsave("wx", wx, 3);
          setsave("wy", wy, 3);
          setsave("time", time, 3);
          setsave("raining", raining, 3);
        }
      }
    };
  }, 100)
};
/*function save() {
  date = new date();
  date = date.getFullYear() + '/' + date.getMonth() + '/' + date.getDate() + ' ' + date.getHours() + ':' + date.getMinutes();
  setsave("date");
  setsave
  if (typeof px != "undefined") {
    lspx = px.toString();
    lspy = py.toString();
    lswx = wx.toString();
    lswy = wy.toString();
  };
  if (typeof px != "undefined") {
    setsave("px" + saveslot, lspx);
    setsave("py" + saveslot, lspy);
    setsave("wx" + saveslot, lswx);
    setsave("wy" + saveslot, lswy);
  };
};*/