/*
0 water
1 grassdirt
2 sand
3 dirt
4 rock
5 tree b
6 berrybush b
7 vinebush b
8 ironrock
9 ironrocksand
! rock sand
@ mushrooms b
# fireout b
s stickssand b
d sticksdirt b
/ fireoutdirt b
l fireoutsand b
^ largetreetop sb
[ largetreebottom b
j junglegrass
b storageboxgrass b
S storageboxjunglegrass b
f freshwater
R rockwater
h rocksaltwater
o obsidian
O obsidianjunglegrass
c blackcoal
C blackcoaljunglegrass
screen 1366 x 768
game 1300 x 728
game pixels 25 x 11
game worlds 4 x 5
block px 52 x 52
block pixels 25 x 11
player pixels 13 x 13
*/
loadwsaves();
var w, rainchance;
var world = {};
world.create = function (wrld, pos) {
  loader(1500);
  eval("w = world" + wrld);
  body.style.backgroundColor = "#" + w[11];
  rainchance = w[12];
  var b, x = 0, y = 0;
  for (let i = 0; i < 11; i++) {
    for (let i2 = 0; i2 < 25; i2++) {
      progress += i * 9;
      eval('var a' + i2.toString() + ' = document.createElement("img")');
      eval('a' + i2.toString() + '.setAttribute("class","worldposa")');
      eval('var b' + i2.toString() + ' = document.createElement("img")');
      eval('b' + i2.toString() + '.setAttribute("class","worldposa")');
      var wb = w[i].substr(i2, 1);
      switch (wb) {
        case "0": b = "water"; break;
        case "1": b = "grassdirt"; break;
        case "2": b = "sand"; break;
        case "3": b = "dirt"; break;
        case "4": b = "rock"; break;
        case "5": b = "tree"; break;
        case "6": b = ""; break;
        case "7": b = ""; break;
        case "8": b = "ironrock"; break;
        case "9": b = "ironrocksand"; break;
        case "!": b = "rocksand"; break;
        case "#": b = "fireout"; break;
        case "s": b = "stickssand"; break;
        case "d": b = "sticksdirt"; break;
        case "@": b = "mushrooms"; break;
        case "/": b = "fireoutdirt"; break;
        case "l": b = "fireoutsand"; break;
        case "^": b = "largetreetop"; break;
        case "[": b = "largetreebottom"; break;
        case "j": b = "junglegrass"; break;
        case "b": b = "storageboxgrass"; break;
        case "S": b = "storageboxjunglegrass"; break;
        case "f": b = "freshwater"; break;
        case "R": b = "rockwater"; break;
        case "h": b = "rocksaltwater"; break;
        case "o": b = "obsidiangrass"; break;
        case "O": b = "obsidianjunglegrass"; break;
        case "c": b = "blackcoal"; break;
        case "C": b = "blackcoaljunglegrass"; break;
      };
      eval('a' + i2.toString() + '.setAttribute("src", "/imgs/blocks/"+b+".png")');
      eval('a' + i2.toString() + '.setAttribute("id", "blockx"+i2+"y"+i)');
      eval('a' + i2.toString() + '.style.top=(i*52+175).toString()+"px"');
      eval('a' + i2.toString() + '.style.left=(i2*52+33).toString()+"px"');
      eval('a' + i2.toString() + '.style.width="52px"');
      eval('a' + i2.toString() + '.setAttribute("draggable", "false")');
      eval('body.appendChild(a' + i2.toString() + ')');
      eval('b' + i2.toString() + '.setAttribute("src", "/imgs/ib.png")');
      eval('b' + i2.toString() + '.setAttribute("id", "x"+i2+"y"+i)');
      eval('b' + i2.toString() + '.style.top=(i*52+181.5).toString()+"px"');
      eval('b' + i2.toString() + '.style.left=(i2*52+39.5).toString()+"px"');
      eval('b' + i2.toString() + '.setAttribute("draggable", "false")');
      eval('b' + i2.toString() + '.setAttribute("width", "0px")');
      eval('body.appendChild(b' + i2.toString() + ')');
    }
  };
};
world.delete = function () {
  var worldimgs = document.getElementsByClassName("worldposa");
  for (let r = 1; r < 551; r++) { body.removeChild(worldimgs[0]); }
};
world.load = function (direction) {
  if (int === true) {
    switch (direction) {
      case "up":
        if (py == 0) { loader(5500); world.delete(); startload(); wy--; py = 10 };
        break;
      case "down":
        if (py == 10) { loader(5500); world.delete(); startload(); wy++; py = 0 };
        break;
      case "left":
        if (px == 0) { loader(5500); world.delete(); startload(); wx--; px = 24 };
        break;
      case "right":
        if (px == 24) { loader(5500); world.delete(); startload(); wx++; px = 0 };
        break;
    }
  };
  function startload() {
    setTimeout(function () {
      world.create("x" + wx.toString() + "y" + wy.toString()); setplayerpos(0);
    }, 1500);
  };
};
function savew() {
  setsave("worldx" + wx + "y" + wy, JSON.stringify(eval("worldx" + wx + "y" + wy)), 3);
};
function breakblock(nblock, nblockname, nb2, nb2name) {
  if (nblock === undefined) {
    var a, b;
    switch (getblock()) {
      case "4": b = "1"; a = "grassdirt"; break;
      case "5": b = "1"; a = "grassdirt"; break;
      case "6": b = "1"; a = "grassdirt"; break;
      case "7": b = "1"; a = "grassdirt"; break;
      case "8": b = "2"; a = "sand"; break;
      case "9": b = "2"; a = "sand"; break;
      case "!": b = "1"; a = "grassdirt"; break;
      case "[": b = "j"; a = "junglegrass"; break;
    }; if (b === "j") { breakjungletree() } else { setblock(b) };
    eval("block" + p.id + ".setAttribute('src', '/imgs/blocks/' + a + '.png')");
  };
  savew();
};
setTimeout(function () {
  world.create("x" + wx.toString().replace("-", "n") + "y" + wy.toString().replace("-", "n"))
}, 2000);
let env = document.createElement("script");
env.setAttribute("src", "/world/environment.js");
body.appendChild(env);
let bf = document.createElement("script");
bf.setAttribute("src", "/world/buildingfunctions.js");
body.appendChild(bf);