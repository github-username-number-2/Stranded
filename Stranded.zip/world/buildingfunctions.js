function createtree() {
  setblock("5"); eval("block" + p.id + ".setAttribute('src', '/imgs/blocks/" + "tree" + ".png')");
  savew();
};
function createjungletree() {
  setblock("[", "^", "up");
  eval("block" + p.id + ".setAttribute('src', '/imgs/blocks/largetreebottom.png')");
  eval("blockx" + p.id.substr(p.id.indexOf("x") + 1, p.id.indexOf("y") - 1) + "y" + (parseInt(p.id.substr(p.id.indexOf("y") + 1)) - 1) + ".setAttribute('src', '/imgs/blocks/largetreetop.png')");
  savew();
};
function breakjungletree() {
  setblock("j", "j", "up"); eval("blockx" + p.id.substr(p.id.indexOf("x") + 1, p.id.indexOf("y") - 1) + "y" + (parseInt(p.id.substr(p.id.indexOf("y") + 1)) - 1) + ".setAttribute('src', '/imgs/blocks/junglegrass.png')");
};
