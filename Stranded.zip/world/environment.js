var time2 = document.createElement("p");
time2.setAttribute("class", "ps2p");
time2.style.top = "150px";
time2.style.right = "20px";
time2.style.zIndex = "4";
time2.innerHTML = time;
body.appendChild(time2);
var timeh, timem, day;
timeh = parseInt(time.slice(time.indexOf(">") + 1, time.lastIndexOf(":")));
timem = parseInt(time.slice(time.indexOf(":") + 1));
var starttime = setInterval(function () {
  timeh = parseInt(time.slice(time.indexOf(">") + 1, time.lastIndexOf(":")));
  timem = parseInt(time.slice(time.indexOf(":") + 1));
  day = time.slice(time.indexOf(" ") + 1, time.indexOf("<"));
  timem++;
  if (timem == 60) {
    timem = 0;
    if (timeh == 23) {
      timeh = 0;
      day++;
      rain();
      eval("dayssurvived" + saveslot + game + "++");
    } else {
      timeh++
    }
  };
  if (timem.toString().length == 1) {
    time = "Day " + day + "<br />" + timeh + ":" + "0" + timem;
  } else {
    time = "Day " + day + "<br />" + timeh + ":" + timem;
  };
  time2.innerHTML = time;
}, 1000);
var nightcover = document.createElement("img");
nightcover.setAttribute("src", "/imgs/eimgs/black.png");
nightcover.setAttribute("class", "posa");
nightcover.setAttribute("draggable", "false");
nightcover.style.width = "1380px";
nightcover.style.height = "800px";
nightcover.style.left = "0px";
nightcover.style.top = "160px";
nightcover.style.opacity = "0";
nightcover.style.zIndex = "4";
body.appendChild(nightcover);
var op = 0;
if (timeh < 6 || timeh > 19) {
  op = 0.9;
  nightcover.style.opacity = op.toString();
};
if (timeh > 6 && timeh < 19) {
  op = 0;
  nightcover.style.opacity = op.toString();
};
if (timeh === 19) {
  op = timem * 0.015;
  nightcover.style.opacity = op.toString();
};
if (timeh === 6) {
  op = 0.9 - timem * 0.015;
  nightcover.style.opacity = op.toString();
};
var daynightcycle = setInterval(function dncycle() {
  if (timeh < 6 || timeh > 19) {
    op = 0.9;
    nightcover.style.opacity = op.toString();
  };
  if (timeh > 6 && timeh < 19) {
    op = 0;
    nightcover.style.opacity = op.toString();
  };
  if (timeh === 19) {
    op = timem * 0.015;
    nightcover.style.opacity = op.toString();
  };
  if (timeh === 6) {
    op = 0.9 - timem * 0.015;
    nightcover.style.opacity = op.toString();
  };
}, 1000);
var rimg = document.createElement('img');
rimg.setAttribute('src', '/imgs/rimg1.png');
rimg.setAttribute('draggable', 'false');
rimg.setAttribute('class', 'posa');
rimg.style.width = '1380px';
rimg.style.height = '800px';
rimg.style.left = '0px';
rimg.style.top = '160px';
rimg.style.zIndex = '3';
rimg.style.opacity = '0.6';
$(rimg).fadeOut(0);
body.appendChild(rimg)
function rain() {
  if (rn(0, 100) <= parseInt(rainchance.substr(0, rainchance.indexOf("%")))) {
    if (raining != "true") { raining = "true" }
  } else {
    raining = "false"
  };
};
var shelter = false;
var rainimgnum = 1;
setInterval(function () {
  if (raining === "true") {
    if (shelter === false) {
      $(rimg).fadeIn(1000);
    } else {
      $(rimg).fadeOut(1000);
    }
  } else {
    $(rimg).fadeOut(1000);
  }
}, 1000);
setInterval(function () {
  if (raining === "true") {
    rimg.setAttribute("src", "/imgs/rimg" + rainimgnum + ".png");
    if (rainimgnum >= 2) { rainimgnum = 1 } else { rainimgnum++ };
  };
}, 300);
progress = 100;
/*
ncover 200x88
day 7 19
dayt 19 20
night 20 6
nightt 6 7
*/