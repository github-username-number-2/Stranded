to do:

make an item storage system
crafting interface
crafting logic
interact logic
finish itimer
fix coordinates
create different move style
minimap
upgrade inventory item adding
add moving between worlds checker
finish worlds
finish making blocks
finish making item icons
upgrade rain
make tutorial
make map
make info section in menu
make skin section in menu
save slot info section in menu
create animals
create fishing
add sounds

images made with https://www.pixilart.com
made by: luke baja ricketts